## Bem-vindo(a) ao meu perfil do GitHub, Syanne karoline aqui👋

- 💻📚 Estudante de ciência da computação - UFPA - 3/8.
- 🌱 Melhorando minhas habilidades em programação.
- ⏲️ Futura atuante na área de IHC.
  
<div align="center">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=syannekaroline&show_icons=true&theme=react&include_all_commits=true&count_private=true&bg_color=1c1131&text_color=A9FEF7&title_color=FE428E&icon_color=CDB33F"/>
</div>

<div align="center">
 <img height="160em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=syannekaroline&layout=compact&langs_count=7&theme=react&bg_color=1c1131&text_color=A9FEF7&title_color=FE428E&icon_color=CDB33F"/>
 <a href="https://picasion.com/"><img src="https://i.picasion.com/pic92/dd9a516e431197ed913a4819155f94fe.gif" width="165" height="165" border="0" alt="https://picasion.com/" /></</a>
</div>

  ##
  
<div align="center"> 
  <a href="https://instagram.com/syanne_karoline" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/syanne-tavares-040b31225" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
  <a href = "mailto:syannekaroline@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  
 ##  🧠 Em processo de aprimoramento...
</div>
